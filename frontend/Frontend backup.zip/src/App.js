import './App.css';
import Card from "./components/Card.js"
import Navbar from './components/Navbar.js';

// In progress icon
import { RiProgress5Line } from "react-icons/ri";

// Plus icon
import { FaPlus } from "react-icons/fa6";

// Three dots icon
import { BsThreeDots } from "react-icons/bs";


function App() {
  return (
    <>
      <Navbar />

      <div className="content">
        <div className="cards-section">
          <div className="card-section-header">
            <div className="card-section-header-left">
              <RiProgress5Line />
              <span>Backlog</span>
              <span>3</span> {/* cards count */}
            </div>
            <div className="card-section-header-right">
              <FaPlus />
              <BsThreeDots />
            </div>
          </div>
          <div className="cards-list">
            <Card />
            <Card />
            <Card />
          </div>
        </div>
        <div className="cards-section">
          <div className="card-section-header">
            <div className="card-section-header-left">
              <RiProgress5Line />
              <span>Backlog</span>
              <span>3</span> {/* cards count */}
            </div>
            <div className="card-section-header-right">
              <FaPlus />
              <BsThreeDots />
            </div>
          </div>
          <div className="cards-list">
            <Card />
            <Card />
            <Card />
          </div>
        </div>
        <div className="cards-section">
          <div className="card-section-header">
            <div className="card-section-header-left">
              <RiProgress5Line style={{ color: "#EDC852" }} />
              <span>Backlog</span>
              <span>3</span> {/* cards count */}
            </div>
            <div className="card-section-header-right">
              <FaPlus />
              <BsThreeDots />
            </div>
          </div>
          <div className="cards-list">
            <Card />
            <Card />
            <Card />
          </div>
        </div>
        <div className="cards-section">
          <div className="card-section-header">
            <div className="card-section-header-left">
              <RiProgress5Line />
              <span>Backlog</span>
              <span>3</span> {/* cards count */}
            </div>
            <div className="card-section-header-right">
              <FaPlus />
              <BsThreeDots />
            </div>
          </div>
          <div className="cards-list">
            <Card />
            <Card />
            <Card />
          </div>
        </div>
        <div className="cards-section">
          <div className="card-section-header">
            <div className="card-section-header-left">
              <RiProgress5Line />
              <span>Backlog</span>
              <span>3</span> {/* cards count */}
            </div>
            <div className="card-section-header-right">
              <FaPlus />
              <BsThreeDots />
            </div>
          </div>
          <div className="cards-list">
            <Card />
            <Card />
            <Card />
          </div>
        </div>
      </div>
    </>
  );
}

export default App;