import React from 'react'

const DisplayTickets = () => {
    return (
        <div></div>
    )
}

export default DisplayTickets